function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  circle (200, 100, 90)
  line (90, 200, 200, 200);
  line (300, 30, 40, 100)
  line (29, 200, 499, 29)
}